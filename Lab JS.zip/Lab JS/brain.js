const navItems = document.querySelectorAll('.nav__item');
const header = document.querySelector('.header');
const nav = document.querySelector('.nav');
const burger = document.querySelector('.burger');

/* document OnLoad */
document.addEventListener("DOMContentLoaded", event => {
	/* Smooth Scroll */
	document.querySelector('.nav__item').classList.add('active');
	window.scrollTo({top: 0, behavior: 'smooth'});

});

window.onload = function() {
	/* Smooth Scroll */

	navItems.forEach(navItem => {
		navItem.addEventListener('click', event => {
			event.preventDefault();

			let elemId = navItem.getAttribute('data-scroll');
			let currentElem = document.querySelector(elemId);

			window.scrollTo({
				top: currentElem.offsetTop,
				behavior: 'smooth'
			});

			navItems.forEach(navItem => {navItem.classList.remove('active')});

			navItem.classList.add('active');


		});

	});


	/* Hide Header OnScroll */
	var prevScroll = 0;

	window.addEventListener('scroll', event => {
		if (prevScroll < window.scrollY) {
			header.classList.add('hide');

		} else {
			header.classList.remove('hide');
		}

		nav.classList.remove('show_mobile');

		prevScroll = window.scrollY;
	});

	/* Burger */
	burger.addEventListener('click', event => {
		nav.classList.toggle('show_mobile');
	});
};